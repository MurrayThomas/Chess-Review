function scoreToCp(s) {
  if (!s) return 0;
  if (s.mate != null) {
    const m = s.mate;
    // Cap at reasonable distance to avoid overflow; mate > 50 treated as "mate in many"
    const dist = Math.min(Math.abs(m), 50);
    return m > 0 ? 10000 - dist * 100 : -10000 + dist * 100;
  }
  return s.cp;
}
function winPct(cp) { return Number.isFinite(cp) && CALIB?.quality?.outcome ? 100 * expectedPoints({cp}, CALIB.quality.outcome) : NaN; }
function moverWin(wr, mover) { const wp = winPct(scoreToCp(wr)); return mover === "w" ? wp : 100 - wp; }
function annotationOutcome(i, state) {
  const build = state.bests[i - 1]?.calibration?.build || state.settings.enginePath;
  return build === "sf19lite" ? SF19_OUTCOME : CALIB?.quality?.outcome;
}
function annotationPoints(score, i, state) {
  try { return 100 * expectedPoints(score, annotationOutcome(i, state)); } catch { return null; }
}
function annotationPair(i, state) {
  const root = state.bests[i - 1], p = state.positions[i];
  const played = p.from + p.to + (p.promotion || "");
  const valid = score => score?.mate != null ? Number.isInteger(score.mate) && score.mate !== 0 : Number.isFinite(score?.cp);
  if (root && Object.hasOwn(root, "playedScore")) {
    const best = root.score, actual = root.bestmove === played ? best : root.playedScore;
    return valid(best) && valid(actual) ? {best, played: actual, paired: true} : null;
  }
  if (!state.evals[i - 1] || !state.evals[i]) return null;
  const sign = p.color === "w" ? 1 : -1;
  const relative = score => score.mate != null ? {mate: score.mate * sign} : {cp: score.cp * sign};
  const lines = root?.lines || [], top = lines.find(line => line.multipv === 1) || lines[0];
  const actual = lines.find(line => (line.pv || "").split(" ")[0] === played);
  const best = top?.score || relative(state.evals[i - 1]);
  const after = actual?.score || relative(state.evals[i]);
  return valid(best) && valid(after) ? {best, played: after, paired: false} : null;
}
function decisionScore(i, which, mover, state) {
  const score = state.annotationEvidence?.[i]?.[which];
  if (!score) return null;
  const sign = state.positions[i].color === mover ? 1 : -1;
  return score.mate != null ? {mate: score.mate * sign} : {cp: score.cp * sign};
}
function decisionPawns(i, which, mover, state) {
  const score = decisionScore(i, which, mover, state);
  return score ? scoreToCp(score) / 100 : null;
}
function decisionMate(i, which, mover, state) {
  return decisionScore(i, which, mover, state)?.mate ?? null;
}
function exchangeGain(chess, square, budget) {
  // Capture trees can reach the same board in different orders. Reuse only completed results;
  // never memoize unknown/exhausted branches. Clock counters do not affect local material gain.
  const memo = budget.memo || (budget.memo = new Map());
  const key = chess.fen().split(" ").slice(0, 4).join(" ") + ":" + square;
  if (memo.has(key)) return memo.get(key);
  if (++budget.nodes > budget.maxNodes) return null;
  if (!chess.get(square) || !chess.attackers(square, chess.turn()).length) { memo.set(key, 0); return 0; }
  const legal = chess.moves({ verbose: true });
  const captures = legal.filter(m => m.to === square && m.captured);
  if (!captures.length) { memo.set(key, 0); return 0; }
  let best = legal.length > captures.length ? 0 : -Infinity;
  for (const m of captures) {
    const reply = exchangeGain(new Chess(m.after), square, budget);
    if (reply == null) return null;
    const promotion = m.promotion ? SAC_VAL[m.promotion] - SAC_VAL.p : 0;
    best = Math.max(best, SAC_VAL[m.captured] + promotion - reply);
  }
  memo.set(key, best);
  return best;
}
function couldBeSaved(chess, square, color, budget = { nodes: 0, maxNodes: 128 }) {
  const piece = chess.get(square);
  if (!piece || piece.color !== color) return false;
  const legal = chess.moves({ verbose: true });
  if (!chess.attackers(square, _opp(color)).length && legal.some(m => m.from !== square)) return true;
  for (const m of legal.sort((a, b) => Number(a.from !== square) - Number(b.from !== square))) {
    const after = new Chess(m.after), to = m.from === square ? m.to : square;
    if (after.get(to)?.color !== color) continue;
    const gain = exchangeGain(after, to, budget);
    if (gain == null) return false;
    if (gain <= (SAC_VAL[m.captured] || 0)) return true;
  }
  return false;
}
function isSacrifice(move) {
  let after, before;
  try { after = new Chess(move.after); before = new Chess(move.before); } catch { return false; }
  if (before.turn() !== move.color || after.turn() !== _opp(move.color)) return false;
  const budget = { nodes: 0, maxNodes: 128 };
  const captured = (SAC_VAL[move.captured] || 0) + (move.promotion ? SAC_VAL[move.promotion] - SAC_VAL.p : 0);
  let priorThreats = null;
  const targets = after.board().flat().filter(p => p && p.color === move.color
    && ["n", "b", "r", "q"].includes(p.type) && after.attackers(p.square, _opp(move.color)).length);
  for (const piece of targets) {
    const square = piece.square;
    const same = before.get(square)?.color === piece.color && before.get(square)?.type === piece.type;
    const source = same ? square : move.from;
    // Do not treat a newly promoted piece or an ambiguous relocated rook as an existing offer.
    if (before.get(source)?.color !== piece.color || before.get(source)?.type !== piece.type) continue;
    const gain = exchangeGain(after, square, budget);
    if (gain == null) return false;
    if (gain <= captured) continue;
    if (same) {
      // A quiet move does not sacrifice an unrelated piece that was already hanging. Compare
      // legal capture consequences, since removing a pin/defender can create a genuine offer.
      // The hypothetical opponent turn has no en-passant right from its own preceding move.
      if (!priorThreats) {
        const fields = before.fen().split(" "); fields[1] = _opp(move.color); fields[3] = "-";
        priorThreats = new Chess(fields.join(" "));
      }
      const previousGain = exchangeGain(priorThreats, square, budget);
      if (previousGain == null) return false;
      // A new check changes the opponent's response obligation. An accepted offer must still
      // be a legal check evasion, as established by exchangeGain after the played move.
      if (gain - captured <= previousGain && !after.isCheck()) {
        // Ignoring a NEW opponent threat can be a tempo sacrifice. History distinguishes that
        // choice from inheriting an offer already present after the mover's previous turn.
        let earlier;
        try { if (move.prior) earlier = new Chess(move.prior); } catch {}
        if (!earlier || earlier.turn() !== _opp(move.color)
          || earlier.get(square)?.color !== piece.color || earlier.get(square)?.type !== piece.type) continue;
        const earlierGain = exchangeGain(earlier, square, budget);
        if (earlierGain == null) return false;
        if (previousGain <= earlierGain) continue;
      }
    }
    if (couldBeSaved(before, source, move.color, budget)) return true;
  }
  return false;
}
function brilliantEligible(i, mover, std, wpDrop, state) {
  if (std[i] !== "excellent" || !Number.isFinite(wpDrop?.[i])) return false;
  const root = state.bests[i - 1], topLine = root?.lines?.[0];
  const afterLine = state.bests[i]?.lines?.[0];
  if ([topLine, ...(state.annotationEvidence[i]?.paired ? [] : [afterLine])].some(l => l?.bound && l.bound !== "exact")) return false;
  const after = decisionPawns(i, "played", mover, state), before = decisionPawns(i, "best", mover, state);
  const mateAfter = decisionMate(i, "played", mover, state), mateBefore = decisionMate(i, "best", mover, state);
  if (!Number.isFinite(after) || !Number.isFinite(before)
    || (mateAfter != null ? mateAfter <= 0 : after < BRILLIANT_POLICY.minAfterPawns)) return false;
  // A sound offer in an undecided position does not depend on a preceding opponent error.
  if (!(mateBefore > 0) && before < BRILLIANT_POLICY.clearlyWinningPawns) return true;
  // Root MultiPV scores are already from the mover's perspective, unlike state.evals. The
  // highest-ranked other move tests whether a clearly winning alternative is available. With
  // only one line this counterfactual is unknown: keep Best/Excellent instead of inventing it.
  const p = state.positions[i], played = (p.from || "") + (p.to || "") + (p.promotion || "");
  const topMove = (topLine?.pv || "").split(" ")[0];
  if (!topMove || topMove !== root?.bestmove || topLine?.multipv !== 1 || !topLine.depth) return false;
  const rank = topMove === played ? 2 : 1;
  const line = root.lines.find(l => l.multipv === rank);
  if (!line || line.bound !== "exact" || line.depth !== topLine.depth) return false;
  const alternative = line.score;
  if (!alternative) return false;
  if (alternative.mate != null) return alternative.mate < 0;
  return Number.isFinite(alternative.cp) && alternative.cp / 100 < BRILLIANT_POLICY.clearlyWinningPawns;
}
function onlyGoodReply(i, state) {
  const root = state.bests[i - 1], top = root?.lines?.find(l => l.multipv === 1);
  const next = root?.lines?.find(l => l.multipv === 2);
  const move = state.positions[i];
  const played = (move.from || "") + (move.to || "") + (move.promotion || "");
  const topMove = (top?.pv || "").split(" ")[0], nextMove = (next?.pv || "").split(" ")[0];
  if (!top || !next || top.bound !== "exact" || next.bound !== "exact"
    || !Number.isInteger(top.depth) || top.depth <= 0 || next.depth !== top.depth
    || topMove !== played || topMove !== root.bestmove || !nextMove || nextMove === topMove
    || !Number.isFinite(top.score?.cp)) return false;
  if (!state.annotationEvidence[i]?.paired && state.bests[i]?.lines?.some(l => l.multipv === 1 && l.bound && l.bound !== "exact")) return false;
  const other = next.score;
  if (!other || (other.mate != null ? !Number.isFinite(other.mate) || other.mate === 0 : !Number.isFinite(other.cp))) return false;
  // Root PVs must identify distinct legal moves, including promotion identity.
  try {
    const before = new Chess(state.positions[i - 1].fen);
    if (before.turn() !== move.color) return false;
    const legal = before.moves({ verbose: true }).map(m => m.from + m.to + (m.promotion || ""));
    if (!legal.includes(topMove) || !legal.includes(nextMove)) return false;
  } catch { return false; }
  const threshold = CALIB?.clsWp?.inacc ?? 5;
  return Number.isFinite(threshold) && threshold > 0
    && annotationPoints(top.score, i, state) - annotationPoints(other, i, state) >= threshold;
}
function _isCheckmate(k, state = S) { try { return new Chess(state.positions[k].fen).isCheckmate(); } catch { return false; } }
function getStandardRating(wp) {
  if (!Number.isFinite(wp)) return null;
  const t = (typeof CALIB !== "undefined" && CALIB?.clsWp) || { good: 2, inacc: 5, blunder: 20 };
  let r = "excellent";
  if (wp >= t.good) r = "good";
  if (wp >= t.inacc) r = "inacc";
  if (wp >= t.blunder) r = "blunder";
  return r;
}
function classifyMove(i, mover, isTop, book, sac, std, loss, wpDrop, state = S) {
  if (book) return "book";
  // "Forced": only one legal move in the position before — we have no separate icon, so it reads
  // as Best (you couldn't have done better).
  if (_forcedAt(i, state)) return "best";   // only one legal move — you couldn't have done better

  // Contextual thresholds in pawns of eval; retain saved values from earlier versions.
  const CA = state.settings.clsClearAdv, ML = state.settings.clsMistakeLoss, MT = state.settings.clsMissTol;
  const mate = (k) => decisionMate(i, k === i ? "played" : "best", mover, state) != null;
  const evalFor = (k) => decisionPawns(i, k === i ? "played" : "best", mover, state);
  const winningNow = (evalFor(i) ?? 0) > 0;
  const prevWinning = (evalFor(i - 1) ?? 0) > 0;
  const notMateRel = !mate(i) && !mate(i - 1);
  const wasNotMateRel = (n) => { const k = i - 1 - n; return k >= 1 && state.annotationEvidence[k]
    && decisionMate(k, "best", state.positions[k].color, state) == null
    && decisionMate(k, "played", state.positions[k].color, state) == null; };
  const pStd = (n) => (i - 1 - n >= 1 ? std[i - 1 - n] : null);
  const pLoss = (n) => (i - 1 - n >= 1 ? loss[i - 1 - n] : null);
  // mover-POV "lost a clear advantage" / "fell into a clear disadvantage" (CA pawns) for move k.
  const losingAdvAt = (k) => { const m = state.positions[k].color; const a = decisionPawns(k, "best", m, state), b = decisionPawns(k, "played", m, state); return a != null && b != null && a >= CA && b < CA; };
  const givingAdvAt = (k) => { const m = state.positions[k].color; const a = decisionPawns(k, "best", m, state), b = decisionPawns(k, "played", m, state); return a != null && b != null && a >= -CA && b < -CA; };
  const keepMating = (k) => { const m = state.positions[k].color, c = decisionMate(k, "played", m, state), p = decisionMate(k, "best", m, state); return c != null && p != null && c > 0 && p > 0 && c <= p; };

  const previousMistake = wasNotMateRel(0) && pStd(0) === "inacc" && pLoss(0) >= ML && (losingAdvAt(i - 1) || givingAdvAt(i - 1));
  const previousPreviousMistake = wasNotMateRel(1) && pStd(1) === "inacc" && pLoss(1) >= ML && (losingAdvAt(i - 2) || givingAdvAt(i - 2));
  const previousMiss = wasNotMateRel(0) && (previousPreviousMistake || pStd(1) === "blunder")
    && (pStd(0) === "blunder" || pStd(0) === "inacc") && (pLoss(0) != null && pLoss(1) != null && pLoss(0) <= pLoss(1) + MT);

  // Material offer and engine quality are separate: board evidence alone cannot prove soundness.
  // Do not reward delays of a known mate or moves that merely remain best in a decided position.
  const beforeMate = decisionMate(i, "best", mover, state), afterMate = decisionMate(i, "played", mover, state);
  const soundMate = !(beforeMate > 0) || (afterMate > 0 && keepMating(i));
  if (sac[i] && soundMate && brilliantEligible(i, mover, std, wpDrop, state)) return "brilliant";

  // Great — an only-good move that capitalises on the opponent's mistake/blunder.
  if (!previousMiss && wasNotMateRel(0) && notMateRel && std[i] === "excellent"
    && (previousMistake || pStd(0) === "blunder") && onlyGoodReply(i, state)) return "great";

  // Mate signs are relative to the mover. Reversing who wins is not delaying one's own mate;
  // already being mated supplies no expected-result reason to reward faster defeat.
  if (beforeMate > 0 && afterMate < 0) return "blunder";
  if (beforeMate > 0 && afterMate > beforeMate) return "good";
  if (beforeMate < 0 && afterMate > 0) return isTop ? "best" : "excellent";
  if (beforeMate < 0 && afterMate < 0) return isTop ? "best" : std[i];

  if (isTop && _isCheckmate(i, state)) return "best";
  if (isTop) return "best";

  if (_isCheckmate(i, state)) return "excellent";
  if (!mate(i - 1) && mate(i) && winningNow) return "excellent";                                             // starts a mate
  if (mate(i - 1) && mate(i) && keepMating(i) && winningNow) return "excellent";                             // keeps the mate

  if (mate(i - 1) && !mate(i) && prevWinning) return "miss";                                                 // threw away a forced mate
  if (!previousMiss && notMateRel && (previousMistake || pStd(0) === "blunder")
    && (std[i] === "blunder" || std[i] === "inacc")
    && evalFor(i) < CA
    && (loss[i] != null && pLoss(0) != null && loss[i] <= pLoss(0) + MT)) return "miss";                     // failed to punish

  if (notMateRel && std[i] === "inacc" && loss[i] >= ML && losingAdvAt(i)) return "mistake";                 // lost a clear advantage
  if (notMateRel && std[i] === "inacc" && loss[i] >= ML && givingAdvAt(i)) return "mistake";                 // handed over a clear advantage
  if (!mate(i - 1) && mate(i) && !winningNow && (evalFor(i - 1) ?? 0) > -CA) return "mistake";               // walked into a mate (wasn't already lost)
  if (!mate(i - 1) && mate(i) && !winningNow) return "blunder";                                              // walked into a mate
  if (mate(i - 1) && mate(i) && !winningNow && prevWinning) return "blunder";                                // threw a win straight into a mate

  // Split the medium-error band the way the expected-points model does: a 10–20% win-drop
  // is a Mistake, 5–10% an Inaccuracy. (Done only here, at the plain-move fallback, so the relational
  // great/miss chains above are untouched.) Threshold from calibration.json.
  if (std[i] === "inacc" && wpDrop && wpDrop[i] != null) {
    const mistWp = (typeof CALIB !== "undefined" && CALIB?.clsWp?.mistake) || 10;
    if (wpDrop[i] >= mistWp) return "mistake";
  }
  return std[i];   // plain excellent / good / inaccuracy / blunder
}
function _forcedAt(i, state = S) {
  if (state._forcedCache[i] !== undefined) return state._forcedCache[i];
  let v = false;
  try { v = new Chess(state.positions[i - 1].fen).moves().length === 1; } catch {}
  state._forcedCache[i] = v;
  return v;
}
function _opp(c) { return c === "w" ? "b" : "w"; }
const SAC_VAL = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
const BRILLIANT_POLICY = { minAfterPawns: -0.5, clearlyWinningPawns: 5 };
